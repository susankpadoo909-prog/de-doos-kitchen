# De Doo's Kitchen

Premium food-service website starter.

Brand slogan: **More Than Food, It's an Experience.**

## Run locally
1. Install Node.js 20 or later.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open http://localhost:3000.

This is a frontend starter only. Ordering, authentication, payments, customer/staff dashboards, payroll, delivery tracking, and database integrations are not implemented yet.
