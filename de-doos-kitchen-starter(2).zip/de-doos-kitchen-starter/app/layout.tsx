import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "De Doo’s Kitchen | More Than Food, It’s an Experience",
  description: "Thoughtfully prepared meals, beautiful flavours and a little luxury in every bite.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
