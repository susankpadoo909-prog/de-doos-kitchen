const dishes = [
  { category: "HOUSE SIGNATURE", name: "Signature Jollof", description: "Smoky party-style rice, finished with our signature kitchen seasoning.", image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=1000&q=85" },
  { category: "CHEF'S SELECTION", name: "Grilled Chicken Platter", description: "Juicy grilled chicken served with carefully prepared sides.", image: "https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=1000&q=85" },
  { category: "FRESH & DELIGHTFUL", name: "Royal Breakfast", description: "A satisfying breakfast selection made fresh for a beautiful start.", image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&w=1000&q=85" },
];

const plans = [
  { name: "Daily", price: "₦20,000", detail: "Breakfast and dinner · 1 day" },
  { name: "Weekly", price: "₦50,000", detail: "Three meals daily · 7 days" },
  { name: "Monthly", price: "₦100,000", detail: "Three meals daily · 30 days" },
  { name: "Quarterly", price: "₦250,000", detail: "Three meals daily · 90 days" },
];

export default function Home() {
  return (
    <>
      <div className="announcement">
        <span>CRAFTED WITH CARE · SERVED WITH LOVE</span>
        <span className="announcement-right">LAGOS, NIGERIA</span>
      </div>
      <header className="site-header">
        <a className="brand" href="#">
          <span className="brand-mark">D</span>
          <span className="brand-copy"><strong>DE DOO’S KITCHEN</strong><small>MORE THAN FOOD</small></span>
        </a>
        <nav className="desktop-nav">
          <a href="#home">Home</a><a href="#menu">Our Menu</a><a href="#subscriptions">Meal Subscriptions</a><a href="#about">About Us</a><a href="#contact">Contact</a>
        </nav>
        <div className="header-actions"><a className="login-link" href="#contact">Sign In</a><a className="button button-small" href="#menu">Order Now</a></div>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-image" />
          <div className="hero-shade" />
          <div className="hero-content">
            <div className="eyebrow">AN ELEVATED FOOD EXPERIENCE</div>
            <h1>More Than Food,<br /><em>It’s an Experience.</em></h1>
            <p className="hero-description">Thoughtfully prepared meals, beautiful flavours and a little luxury in every bite. Welcome to De Doo’s Kitchen.</p>
            <div className="hero-actions"><a className="button" href="#menu">EXPLORE OUR MENU</a><a className="text-link light-link" href="#about">DISCOVER OUR STORY →</a></div>
            <div className="hero-note"><span /> FRESHLY PREPARED · MADE TO DELIGHT</div>
          </div>
          <div className="hero-side-label">GOOD FOOD. BEAUTIFULLY DONE.</div>
        </section>

        <section className="intro section-wrap" id="about">
          <div className="intro-kicker">WELCOME TO DE DOO’S KITCHEN</div>
          <div className="intro-grid">
            <h2>Where every meal<br />feels <em> 특별.</em></h2>
            <div className="intro-copy"><p>We believe food should do more than satisfy hunger. It should bring comfort, create memories and make ordinary moments feel special.</p><a className="text-link" href="#menu">GET TO KNOW OUR MENU →</a></div>
          </div>
        </section>

        <section className="menu-section" id="menu">
          <div className="section-wrap">
            <div className="section-heading"><div><div className="eyebrow dark-eyebrow">A TASTE OF WHAT WE DO</div><h2>Made to be <em>remembered.</em></h2></div><p>Explore a selection of kitchen favourites. Menu items and availability can be configured as the full ordering system is developed.</p></div>
            <div className="dish-grid">{dishes.map((dish) => <article className="dish-card" key={dish.name}><div className="dish-image" style={{backgroundImage:`url("${dish.image}")`}} /><div className="dish-info"><div className="dish-category">{dish.category}</div><h3>{dish.name}</h3><p>{dish.description}</p><div className="dish-bottom"><span>DE DOO’S KITCHEN</span><span className="coming-soon">ENQUIRE FOR DETAILS</span></div></div></article>)}</div>
            <p className="demo-note">Menu imagery and descriptions are illustrative placeholders pending final menu approval.</p>
          </div>
        </section>

        <section className="subscription-section" id="subscriptions">
          <div className="section-wrap">
            <div className="center-heading"><div className="eyebrow">GOOD FOOD, ON YOUR SCHEDULE</div><h2>Make every day <em>delicious.</em></h2><p>Choose a meal plan that suits your routine. These proposed plans are subject to final pricing and menu confirmation.</p></div>
            <div className="plan-grid">{plans.map((plan) => <article className="plan-card" key={plan.name}><div className="plan-duration">MEAL SUBSCRIPTION</div><h3>{plan.name}</h3><div className="plan-price">{plan.price}</div><p>{plan.detail}</p><a className="plan-link" href="#contact">ENQUIRE NOW <span>→</span></a></article>)}</div>
          </div>
        </section>

        <section className="promise-section"><div className="section-wrap promise-grid"><div><h3>Made with intention</h3><p>Thoughtful preparation and attention to the details that make a meal memorable.</p></div><div><h3>For your everyday</h3><p>Flexible food options for daily enjoyment, gatherings and meal planning.</p></div><div><h3>Hospitality first</h3><p>A warm, attentive experience from your first enquiry to your last bite.</p></div></div></section>

        <section className="closing-cta" id="contact"><div className="eyebrow">YOUR TABLE IS WAITING</div><h2>Let’s make something<br /><em>delicious happen.</em></h2><a className="button" href="mailto:hello@dedooskitchen.com">CONTACT DE DOO’S KITCHEN</a></section>
      </main>
      <footer className="footer"><div className="footer-main"><div className="brand"><span className="brand-mark">D</span><span className="brand-copy"><strong>DE DOO’S KITCHEN</strong><small>MORE THAN FOOD</small></span></div><p>More Than Food, It’s an Experience.</p><div className="footer-links"><a href="#menu">Menu</a><a href="#subscriptions">Subscriptions</a><a href="#contact">Contact</a></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} De Doo’s Kitchen</span><span>Crafted with care.</span></div></footer>
    </>
  );
}
